package com.ey;

import java.util.Map;

public class BookMyMovie {
    private int movieId;
    private int noOfTickets;
    private double baseFare;
    private double discount;

    // Constructor to initialize movieId and noOfTickets
    public BookMyMovie(int movieId, int noOfTickets, Map<Integer, Double> baseFares) {
        this.movieId = movieId;
        this.noOfTickets = noOfTickets;
        // Initialize baseFare based on movieId
        this.baseFare = getBaseFare(movieId, baseFares);
        // Calculate discount percentage based on movieId and noOfTickets
        calculateDiscount();
    }

    // Method to calculate discount based on movieId and noOfTickets
    private void calculateDiscount() {
        if (movieId == 101 || movieId == 103) {
            if (noOfTickets < 5) {
                discount = 0;
            } else if (noOfTickets >= 5 && noOfTickets <= 10) {
                discount = 15;
            } else if (noOfTickets > 10 && noOfTickets <= 15) {
                discount = 20;
            }
        } else if (movieId == 102) {
            if (noOfTickets >= 5 && noOfTickets < 10) {
                discount = 10;
            } else if (noOfTickets >= 10 && noOfTickets <= 15) {
                discount = 15;
            }
        } else {
            throw new InvalidMovieIdException("Invalid movie ID: " + movieId);
        }
    }

    // Method to calculate total ticket amount after applying discount
    public double calculateTicketAmount() {
        double totalAmount = baseFare * noOfTickets * (1 - discount / 100.0);
        return totalAmount;
    }

    // Method to get baseFare based on movieId
    private double getBaseFare(int movieId, Map<Integer, Double> baseFares) {
        if (baseFares.containsKey(movieId)) {
            return baseFares.get(movieId);
        } else {
            throw new InvalidMovieIdException("Invalid movie ID: " + movieId);
        }
    }

    // Getter methods for testing purposes
    public double getBaseFare() {
        return baseFare;
    }

    public double getDiscount() {
        return discount;
    }
}
