package com.ey;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
public class BookMyMovieTester {
    public static void main(String[] args) {
        // Read base fares from movie.txt
        Map<Integer, Double> baseFares = readBaseFaresFromFile("movie.txt");
        // Test cases as per the problem statement
        testBookMyMovie(101, 5, baseFares); // Expected output: Total amount for booking 1: 600.0
        testBookMyMovie(102, 4, baseFares); // Expected output: Total amount for booking 2: 646.0
        testBookMyMovie(103, 8, baseFares); // Expected output: Total amount for booking 3: 960.0
    }
    // Method to test BookMyMovie class with given movieId and noOfTickets
    private static void testBookMyMovie(int movieId, int noOfTickets, Map<Integer, Double> baseFares) {
        try {
            BookMyMovie bm = new BookMyMovie(movieId, noOfTickets, baseFares);
            double totalAmount = bm.calculateTicketAmount();
            System.out.println("Total amount for booking: " + totalAmount);
        } catch (InvalidMovieIdException e) {
            System.out.println(e.getMessage());
        }
    }
    // Method to read base fares from movie.txt
    private static Map<Integer, Double> readBaseFaresFromFile(String movie) {
        Map<Integer, Double> baseFares = new HashMap<>();
        try {
            // Replace with your actual file path
            // For example: /path/to/your/project/movie.txt
            // Make sure movie.txt is in the correct location
            Files.lines(Paths.get("C:\Users\Administrator\Desktop\d\eclipse-workspace\Question2\src\com\ey"))
                    .map(line -> line.split("="))
                    .forEach(parts -> {
                        int movieId = Integer.parseInt(parts[0].trim());
                        double baseFare = Double.parseDouble(parts[1].trim());
                        baseFares.put(movieId, baseFare);
                    });
        } catch (IOException | NumberFormatException e) {
            // Handle file reading or parsing errors
            e.printStackTrace();
        }
        return baseFares;
    }
}